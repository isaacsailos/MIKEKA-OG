# MIKEKA OG

Android betting tips app starter.

## Current version
- Dark/Gold UI
- Free Tips screen
- Premium Tips screen
- Account screen
- Bottom navigation

## Next development stages
1. Firebase project and database
2. Admin authentication
3. Admin dashboard
4. Add/edit/delete tips
5. Users and authentication
6. Premium access and payments
7. Push notifications
8. Testing and release APK

## Run
Install Flutter, then:

flutter pub get
flutter run
