import 'package:flutter/material.dart';

void main() {
  runApp(const MikekaOgApp());
}

class MikekaOgApp extends StatelessWidget {
  const MikekaOgApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MIKEKA OG',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF090909),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFD4AF37),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedIndex = 0;

  final pages = const [
    TipsScreen(),
    PremiumScreen(),
    AccountScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF090909),
        title: const Text(
          'MIKEKA OG',
          style: TextStyle(
            fontWeight: FontWeight.w900,
            letterSpacing: 1.5,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.notifications_none),
          ),
        ],
      ),
      body: pages[selectedIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        backgroundColor: const Color(0xFF111111),
        indicatorColor: const Color(0xFF3A3218),
        onDestinationSelected: (index) {
          setState(() => selectedIndex = index);
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.sports_soccer_outlined),
            selectedIcon: Icon(Icons.sports_soccer),
            label: 'Tips',
          ),
          NavigationDestination(
            icon: Icon(Icons.workspace_premium_outlined),
            selectedIcon: Icon(Icons.workspace_premium),
            label: 'Premium',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Account',
          ),
        ],
      ),
    );
  }
}

class TipsScreen extends StatelessWidget {
  const TipsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionTitle('🔥 FREE TIPS'),
        const TipCard(
          title: 'MKeka wa Leo',
          odds: '8.50',
          status: 'PENDING',
          premium: false,
        ),
        const SizedBox(height: 16),
        _sectionTitle('💎 PREMIUM TIPS'),
        const TipCard(
          title: 'VIP Accumulator',
          odds: '25.40',
          status: 'LOCKED',
          premium: true,
        ),
      ],
    );
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Text(
          text,
          style: const TextStyle(
            color: Color(0xFFD4AF37),
            fontWeight: FontWeight.bold,
            fontSize: 17,
          ),
        ),
      );
}

class PremiumScreen extends StatelessWidget {
  const PremiumScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.workspace_premium, size: 70, color: Color(0xFFD4AF37)),
            SizedBox(height: 16),
            Text(
              'PREMIUM TIPS',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
            ),
            SizedBox(height: 10),
            Text(
              'Premium tips zitaonekana hapa baada ya mfumo wa malipo kuunganishwa.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70),
            ),
          ],
        ),
      ),
    );
  }
}

class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: const [
        ListTile(
          leading: Icon(Icons.person, color: Color(0xFFD4AF37)),
          title: Text('Account'),
          subtitle: Text('Login/Register itaongezwa'),
        ),
        Divider(),
        ListTile(
          leading: Icon(Icons.history),
          title: Text('My Purchases'),
        ),
        ListTile(
          leading: Icon(Icons.notifications_none),
          title: Text('Notifications'),
        ),
      ],
    );
  }
}

class TipCard extends StatelessWidget {
  final String title;
  final String odds;
  final String status;
  final bool premium;

  const TipCard({
    super.key,
    required this.title,
    required this.odds,
    required this.status,
    required this.premium,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFF151515),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                if (premium)
                  const Icon(Icons.lock, color: Color(0xFFD4AF37)),
              ],
            ),
            const SizedBox(height: 12),
            Text('Total Odds: $odds'),
            const SizedBox(height: 6),
            Text(
              status,
              style: const TextStyle(
                color: Color(0xFFD4AF37),
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () {},
                child: Text(premium ? 'FUNGUA PREMIUM' : 'ANGALIA MKEKA'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
